__version__ = "1.0.0b2"  # don't forget to update also the wxglade shell script, sphinx/conf.py and wxGlade.desktop
