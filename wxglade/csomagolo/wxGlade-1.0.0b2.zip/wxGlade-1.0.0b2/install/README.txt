This directory is for building Windows installers.
Currently this is not being used as wxGlade is distributed as source only.


To start wxGlade, enter 'python3 wxglade.py' or 'python wxglade.py'
in your shell or use whatever is required to start a python application on
your platform.
If you want to build a GUI for wxPython Classic or Phoenix:
Start wxGlade in your target version - if it runs under Phoenix, it will
create Phoenix code.
